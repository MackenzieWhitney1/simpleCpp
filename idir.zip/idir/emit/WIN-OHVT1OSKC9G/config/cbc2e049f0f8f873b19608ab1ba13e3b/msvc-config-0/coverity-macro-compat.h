﻿
#if !(defined(_MSC_VER) || defined(__coverity_undefine__MSC_VER))
#define _MSC_VER 1700
#endif
#if !(defined(_MSC_FULL_VER) || defined(__coverity_undefine__MSC_FULL_VER))
#define _MSC_FULL_VER 170050727
#endif
#if !(defined(_M_IX86) || defined(__coverity_undefine__M_IX86))
#define _M_IX86 600
#endif
#if !(defined(_WIN32) || defined(__coverity_undefine__WIN32))
#define _WIN32 1
#endif
#if !(defined(_M_IX86_FP) || defined(__coverity_undefine__M_IX86_FP))
#define _M_IX86_FP 2
#endif
#if !(defined(__COUNTER__) || defined(__coverity_undefine___COUNTER__))
#define __COUNTER__ 0
#endif
#if !(defined(_INTEGRAL_MAX_BITS) || defined(__coverity_undefine__INTEGRAL_MAX_BITS))
#define _INTEGRAL_MAX_BITS 64
#endif
#if !(defined(_MSC_BUILD) || defined(__coverity_undefine__MSC_BUILD))
#define _MSC_BUILD 1
#endif
#if !(defined(_MSC_EXTENSIONS) || defined(__coverity_undefine__MSC_EXTENSIONS))
#define _MSC_EXTENSIONS 1
#endif
#if !(defined(_MT) || defined(__coverity_undefine__MT))
#define _MT 1
#endif
